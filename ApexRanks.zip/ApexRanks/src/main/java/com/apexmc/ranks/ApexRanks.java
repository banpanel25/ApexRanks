package com.apexmc.ranks;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class ApexRanks extends JavaPlugin implements Listener, TabExecutor {

    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("rank")).setExecutor(this);
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
        getLogger().info("ApexRanks enabled with " + rankIds().size() + " ranks.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) clear(p);
    }

    // ---------------- Data ----------------

    private void loadData() {
        dataFile = new File(getDataFolder(), "players.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save players.yml: " + e.getMessage());
        }
    }

    private Set<String> rankIds() {
        ConfigurationSection s = getConfig().getConfigurationSection("ranks");
        return s == null ? Set.of() : s.getKeys(false);
    }

    private String findRank(String input) {
        for (String id : rankIds()) if (id.equalsIgnoreCase(input)) return id;
        return null;
    }

    private String getRank(UUID uuid) {
        String r = data.getString("players." + uuid);
        if (r == null || !getConfig().contains("ranks." + r)) {
            return getConfig().getString("default-rank", "member");
        }
        return r;
    }

    private String msgPrefix() {
        return getConfig().getString("messages.prefix", "&8[&cApex&8] &7");
    }

    private void msg(CommandSender to, String text) {
        to.sendMessage(legacy.deserialize(msgPrefix() + text));
    }

    // ---------------- Permissions ----------------

    /** Collects nodes with parents first so child ranks override parents. */
    private void collect(String rank, LinkedHashSet<String> out, Set<String> visited) {
        if (rank == null || !visited.add(rank)) return;
        ConfigurationSection sec = getConfig().getConfigurationSection("ranks." + rank);
        if (sec == null) return;
        for (String parent : sec.getStringList("inherits")) collect(parent, out, visited);
        String single = sec.getString("inherits");
        if (single != null) collect(single, out, visited);
        out.addAll(sec.getStringList("permissions"));
    }

    private void clear(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) {
            try {
                p.removeAttachment(old);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void apply(Player p) {
        clear(p);
        String rank = getRank(p.getUniqueId());
        PermissionAttachment att = p.addAttachment(this);
        attachments.put(p.getUniqueId(), att);

        LinkedHashSet<String> nodes = new LinkedHashSet<>();
        collect(rank, nodes, new HashSet<>());
        for (String node : nodes) {
            if (node.equals("*")) {
                for (Permission perm : Bukkit.getPluginManager().getPermissions()) {
                    att.setPermission(perm.getName(), true);
                }
                continue;
            }
            boolean value = !node.startsWith("-");
            att.setPermission(value ? node : node.substring(1), value);
        }
        p.recalculatePermissions();
        p.updateCommands();
        p.playerListName(legacy.deserialize(prefixOf(rank) + p.getName()));
    }

    private String prefixOf(String rank) {
        return getConfig().getString("ranks." + rank + ".prefix", "");
    }

    // ---------------- Events ----------------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        apply(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        clear(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncChatEvent e) {
        Component prefix = legacy.deserialize(prefixOf(getRank(e.getPlayer().getUniqueId())));
        boolean color = e.getPlayer().hasPermission("essentials.chat.color");
        e.renderer((source, name, message, viewer) -> {
            Component body = color
                    ? legacy.deserialize(net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                            .plainText().serialize(message))
                    : message;
            return Component.empty()
                    .append(prefix)
                    .append(name)
                    .append(legacy.deserialize("&8: &f"))
                    .append(body);
        });
    }

    // ---------------- Command ----------------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof org.bukkit.command.ConsoleCommandSender) && !s.hasPermission("apexranks.admin")) {
            msg(s, "&cYou don't have permission.");
            return true;
        }
        if (a.length == 0) {
            msg(s, "Usage: /rank <set|remove|info|list|reload>");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "set" -> {
                if (a.length < 3) {
                    msg(s, "Usage: /rank set <player> <rank>");
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
                if (!t.isOnline() && !t.hasPlayedBefore()) {
                    msg(s, "&cThat player has never joined the server.");
                    return true;
                }
                String rank = findRank(a[2]);
                if (rank == null) {
                    msg(s, "&cUnknown rank. Use /rank list.");
                    return true;
                }
                data.set("players." + t.getUniqueId(), rank);
                saveData();
                if (t.getPlayer() != null) apply(t.getPlayer());
                msg(s, "Set &f" + a[1] + "&7's rank to &f" + rank + "&7.");
            }
            case "remove" -> {
                if (a.length < 2) {
                    msg(s, "Usage: /rank remove <player>");
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
                data.set("players." + t.getUniqueId(), null);
                saveData();
                if (t.getPlayer() != null) apply(t.getPlayer());
                msg(s, "Reset &f" + a[1] + "&7 to the default rank.");
            }
            case "info" -> {
                if (a.length < 2) {
                    msg(s, "Usage: /rank info <player>");
                    return true;
                }
                OfflinePlayer t = Bukkit.getOfflinePlayer(a[1]);
                msg(s, a[1] + " has rank &f" + getRank(t.getUniqueId()) + "&7.");
            }
            case "list" -> {
                String list = rankIds().stream()
                        .sorted(Comparator.comparingInt((String id) -> getConfig().getInt("ranks." + id + ".weight")).reversed())
                        .collect(Collectors.joining("&7, &f"));
                msg(s, "Ranks: &f" + list);
            }
            case "reload" -> {
                reloadConfig();
                loadData();
                for (Player p : Bukkit.getOnlinePlayers()) apply(p);
                msg(s, "Config reloaded.");
            }
            default -> msg(s, "Usage: /rank <set|remove|info|list|reload>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 1) return filter(List.of("set", "remove", "info", "list", "reload"), a[0]);
        if (a.length == 2 && !a[0].equalsIgnoreCase("list") && !a[0].equalsIgnoreCase("reload")) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        }
        if (a.length == 3 && a[0].equalsIgnoreCase("set")) return filter(new ArrayList<>(rankIds()), a[2]);
        return List.of();
    }

    private List<String> filter(List<String> opts, String start) {
        return opts.stream().filter(o -> o.toLowerCase().startsWith(start.toLowerCase())).toList();
    }
}
